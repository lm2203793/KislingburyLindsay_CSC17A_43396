var files_dup =
[
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "Card.h", "_card_8h.html", "_card_8h" ],
    [ "Cplayer.cpp", "_cplayer_8cpp.html", null ],
    [ "Cplayer.h", "_cplayer_8h.html", [
      [ "Cplayer", "class_cplayer.html", "class_cplayer" ]
    ] ],
    [ "Deck.cpp", "_deck_8cpp.html", null ],
    [ "Deck.h", "_deck_8h.html", [
      [ "Deck", "class_deck.html", "class_deck" ]
    ] ],
    [ "GmScore.h", "_gm_score_8h.html", [
      [ "GmScore", "struct_gm_score.html", "struct_gm_score" ]
    ] ],
    [ "Hplayer.cpp", "_hplayer_8cpp.html", null ],
    [ "Hplayer.h", "_hplayer_8h.html", [
      [ "Hplayer", "class_hplayer.html", "class_hplayer" ],
      [ "BadChc", "class_hplayer_1_1_bad_chc.html", "class_hplayer_1_1_bad_chc" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Player.cpp", "_player_8cpp.html", null ],
    [ "Player.h", "_player_8h.html", [
      [ "Player", "class_player.html", "class_player" ]
    ] ],
    [ "Type.h", "_type_8h.html", "_type_8h" ]
];