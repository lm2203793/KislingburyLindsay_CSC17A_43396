var main_8cpp =
[
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "plyGame", "main_8cpp.html#a0d961fde5a15e96b088f415fb17af828", null ],
    [ "prcCard", "main_8cpp.html#a13b60e5402bf362e573154ff2af3c2f5", null ],
    [ "rdScr", "main_8cpp.html#a01970240845f9963d2d3f0914d45d5ed", null ],
    [ "setPlyr", "main_8cpp.html#a90290adb68a7d6c6c2aea1ed2d94e13d", null ],
    [ "uno", "main_8cpp.html#afbeefa77154497d5adf324d84ea1fba9", null ],
    [ "unoFlag", "main_8cpp.html#a5e80cc8a27a16d7cdf85a5c84c984f89", null ],
    [ "valPlay", "main_8cpp.html#a7eedbe16dfbab1f9091c8ee67121ed30", null ],
    [ "wrtScr", "main_8cpp.html#a1902fd38edd4142caff546218e7a61c7", null ]
];