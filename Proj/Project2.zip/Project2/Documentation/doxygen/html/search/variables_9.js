var searchData=
[
  ['win_202',['win',['../struct_gm_score.html#ad821aaf655247f45b46170fe04dae107',1,'GmScore']]],
  ['winner_203',['winner',['../class_player.html#a9fbdb1f60c5399530c52d1ad1a9a7406',1,'Player']]]
];
