var searchData=
[
  ['plyrnum_197',['plyrNum',['../class_player.html#a27f65e34e88a90f7b63525b2e1567c6d',1,'Player']]],
  ['points_198',['points',['../class_card.html#a123c140179154f23df1737fa0d9aaa0a',1,'Card']]]
];
