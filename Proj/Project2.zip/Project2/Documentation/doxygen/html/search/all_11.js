var searchData=
[
  ['wild_97',['WILD',['../_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a36e0b0601d7046be14882048365a8970',1,'Type.h']]],
  ['wild4_98',['WILD4',['../_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7adeeabcce0f991ff2b7e4f20894fc00f2',1,'Type.h']]],
  ['win_99',['win',['../struct_gm_score.html#ad821aaf655247f45b46170fe04dae107',1,'GmScore']]],
  ['winner_100',['winner',['../class_player.html#a9fbdb1f60c5399530c52d1ad1a9a7406',1,'Player']]],
  ['wrtscr_101',['wrtScr',['../main_8cpp.html#a1902fd38edd4142caff546218e7a61c7',1,'main.cpp']]]
];
