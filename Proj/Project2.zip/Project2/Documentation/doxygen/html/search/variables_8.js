var searchData=
[
  ['unoflag_201',['unoFlag',['../class_player.html#a9e9f4fe5f30950d3f9f8622a59c9dc4a',1,'Player']]]
];
