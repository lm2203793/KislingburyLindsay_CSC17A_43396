var searchData=
[
  ['name_50',['name',['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['nm_51',['nm',['../struct_gm_score.html#a775c24283343200f7f7822105a59cb43',1,'GmScore']]],
  ['num_52',['num',['../class_card.html#a8476156e35f853203a7f38dde12ed75d',1,'Card']]],
  ['number_53',['NUMBER',['../_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a12a90dfe20486bbe3e075afcd19ef2d0',1,'Type.h']]]
];
