var searchData=
[
  ['gmscore_106',['GmScore',['../struct_gm_score.html',1,'']]]
];
