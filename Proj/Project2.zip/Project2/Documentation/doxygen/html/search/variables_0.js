var searchData=
[
  ['cards_186',['cards',['../class_deck.html#a1dd171aef1d4d37679a368113be72447',1,'Deck']]],
  ['colname_187',['colName',['../class_card.html#af9382a9c8cede2142daf1846d1bd92ed',1,'Card']]],
  ['color_188',['color',['../class_card.html#a34bdc7fcfd89d2f33c2f4dd26d15241b',1,'Card']]]
];
