var searchData=
[
  ['type_200',['type',['../class_card.html#aecdd56ffb135684141ae85fa5d23d992',1,'Card']]]
];
