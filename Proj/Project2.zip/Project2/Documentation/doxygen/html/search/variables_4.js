var searchData=
[
  ['name_194',['name',['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['nm_195',['nm',['../struct_gm_score.html#a775c24283343200f7f7822105a59cb43',1,'GmScore']]],
  ['num_196',['num',['../class_card.html#a8476156e35f853203a7f38dde12ed75d',1,'Card']]]
];
