var searchData=
[
  ['operator_3c_3c_54',['operator&lt;&lt;',['../class_card.html#a53a3adbcbe5467d4379e1ca6ae5ea29c',1,'Card::operator&lt;&lt;()'],['../_card_8h.html#a19eb35e24a8f6368e34575698fca9008',1,'operator&lt;&lt;():&#160;Card.h']]]
];
