var class_cplayer =
[
    [ "Cplayer", "class_cplayer.html#a8f8c68832a04c4d7fb25d88211f3fbc6", null ],
    [ "chsWild", "class_cplayer.html#afc3bd8b678639c3f4085dcce9d83b21d", null ],
    [ "getPcrd", "class_cplayer.html#aceb7a84f47e64c434ab0704e963b3800", null ],
    [ "scoreClr", "class_cplayer.html#af45ced52410666c333a369b4e08368d5", null ],
    [ "scoreSym", "class_cplayer.html#a86063f175fd386aa6ffe6e09f524286b", null ],
    [ "scrCrdsC", "class_cplayer.html#a9f8e8ec04f971ac7a06d56c1c206f18e", null ],
    [ "scrCrdsN", "class_cplayer.html#a5a14f09d530988dd6219c12662bf7d9c", null ],
    [ "sCrdsA", "class_cplayer.html#a90d2a403a7a22b57c2b33e666d80c6a8", null ],
    [ "setHrd", "class_cplayer.html#aad3d7d50aa208e6e5a66107ca70cd1e1", null ]
];