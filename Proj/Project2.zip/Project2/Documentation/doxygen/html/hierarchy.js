var hierarchy =
[
    [ "Hplayer::BadChc", "class_hplayer_1_1_bad_chc.html", null ],
    [ "Card", "class_card.html", null ],
    [ "Deck", "class_deck.html", null ],
    [ "GmScore", "struct_gm_score.html", null ],
    [ "Player", "class_player.html", [
      [ "Cplayer", "class_cplayer.html", null ],
      [ "Hplayer", "class_hplayer.html", null ]
    ] ]
];