var _type_8h =
[
    [ "Type", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "NUMBER", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a12a90dfe20486bbe3e075afcd19ef2d0", null ],
      [ "SKIP", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a998eded080e73768c0b44bf4891df984", null ],
      [ "REVERSE", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a906b7cc20b42994dda4da492767c1de9", null ],
      [ "DRAW2", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a54cc8bfabdbd65aad87e2c423dc4f49d", null ],
      [ "WILD", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7a36e0b0601d7046be14882048365a8970", null ],
      [ "WILD4", "_type_8h.html#a1d1cfd8ffb84e947f82999c682b666a7adeeabcce0f991ff2b7e4f20894fc00f2", null ]
    ] ]
];