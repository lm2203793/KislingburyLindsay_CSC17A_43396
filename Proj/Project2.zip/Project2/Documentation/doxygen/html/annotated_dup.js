var annotated_dup =
[
    [ "Card", "class_card.html", "class_card" ],
    [ "Cplayer", "class_cplayer.html", "class_cplayer" ],
    [ "Deck", "class_deck.html", "class_deck" ],
    [ "GmScore", "struct_gm_score.html", "struct_gm_score" ],
    [ "Hplayer", "class_hplayer.html", "class_hplayer" ],
    [ "Player", "class_player.html", "class_player" ]
];