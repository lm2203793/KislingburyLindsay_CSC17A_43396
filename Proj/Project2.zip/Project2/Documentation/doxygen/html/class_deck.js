var class_deck =
[
    [ "Deck", "class_deck.html#a57ae1cb4ac6fd61c249cefb2db85eb99", null ],
    [ "chngDisc", "class_deck.html#a75888d697fc2b62279135cb6fa1a4783", null ],
    [ "dealCrds", "class_deck.html#a5016c47b42aebed96a123ddb78839c99", null ],
    [ "drawCard", "class_deck.html#a7e3cb5a726dec9953c564ab7d780563d", null ],
    [ "filCrds", "class_deck.html#a2420ddd6010f8d771841edb2f8dac4bd", null ],
    [ "getDis", "class_deck.html#a4e72d23f46d266c219282a0ab5235db7", null ],
    [ "getdisC", "class_deck.html#a9f5b7a595ac16a2288458b90b1714432", null ],
    [ "getDiscN", "class_deck.html#a522f504eb0bbd5d6838bbe0e874854a3", null ],
    [ "getDisT", "class_deck.html#a8d53ae627a1883acd472c06ae0b9ab57", null ],
    [ "reFill", "class_deck.html#a459b2da0ca26bee3d800f83e8c1dcfe3", null ],
    [ "setDscrd", "class_deck.html#a3165992c0a46cf829bc7028d05f3a182", null ],
    [ "shuffle", "class_deck.html#ae5a1e52ab00ae5924f2bc6b730dba3eb", null ],
    [ "cards", "class_deck.html#a1dd171aef1d4d37679a368113be72447", null ],
    [ "discard", "class_deck.html#ab006d34352abf3730d77757046b42347", null ],
    [ "dPile", "class_deck.html#aefa7e1706933734e81fa559b700fba82", null ]
];