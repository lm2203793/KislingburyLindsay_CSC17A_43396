var struct_gm_score =
[
    [ "lrgHnd", "struct_gm_score.html#a65d979cf78c6c4e0f26e13dfa2cf9e89", null ],
    [ "nm", "struct_gm_score.html#a775c24283343200f7f7822105a59cb43", null ],
    [ "win", "struct_gm_score.html#ad821aaf655247f45b46170fe04dae107", null ]
];