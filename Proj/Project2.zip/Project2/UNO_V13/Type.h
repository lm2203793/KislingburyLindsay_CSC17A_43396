
#ifndef TYPE_H
#define TYPE_H

enum Type{NUMBER,SKIP,REVERSE,
            DRAW2,WILD,WILD4};       //Card Types


#endif /* TYPE_H */

