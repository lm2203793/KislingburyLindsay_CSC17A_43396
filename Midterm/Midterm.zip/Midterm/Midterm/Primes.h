/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on April 25, 2021 6:12PM
 * Purpose:  Midterm Problem #7 Primes Structure
 */

#ifndef PRIMES_H
#define PRIMES_H

struct Primes{
    unsigned short nPrimes;
    Prime *prime;
};

#endif /* PRIMES_H */

