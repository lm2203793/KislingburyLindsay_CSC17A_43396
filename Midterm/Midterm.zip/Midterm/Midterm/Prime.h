/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on April 25, 2021 6:12PM
 * Purpose:  Midterm Problem #7 Prime Structure
 */

#ifndef PRIME_H
#define PRIME_H

struct Prime{
    unsigned short prime;
    unsigned short power;
};

#endif /* PRIME_H */

